function calculateArea(length, width){
    return length*width;
}

console.log(calculateArea(10,40));