        n=prompt("Enter a number : ");
        if(n>0){
            console.log(n+" is positive");
        }
        else if(n<0){
            console.log(n+" is negative");
        }
        else{
            console.log(n+" is zero");
        }
