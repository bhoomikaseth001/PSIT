//Write a Js program that prints numbers from 1 to 10 using a for and a while loop
        console.log("Using for loop");
    for(let a=1;a<=10;a++){
        console.log(a+" ");
    }

    console.log("Using while loop");
    let b=1;
    while(b<=10){
        console.log(b+" ");
        b++;
    }
