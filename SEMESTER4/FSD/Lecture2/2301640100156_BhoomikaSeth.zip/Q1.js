    n=prompt();
    console.log(n*n);

