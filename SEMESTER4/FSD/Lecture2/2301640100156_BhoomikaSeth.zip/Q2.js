//    let name= prompt("Enter your name");
//    console.log(name,typeof name);
//    let roll_no = Number(prompt("Enter the roll no. "));
//    console.log(roll_no, typeof roll_no);
//    let val =true;
//     console.log(val,typeof val)

let a=5;
let b=4.6;
let c= "bhoomika"
let d= true;

console.log(a, typeof a);
console.log(b, typeof b);
console.log(c, typeof c);
console.log(d, typeof d);
